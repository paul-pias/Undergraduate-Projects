Name: Pias Paul
ID#   1410542042

Programming Language used: Python

For the compilation I have used
                    -'Pycharm' as my platform
                    -In the commandline argument instructions are case sensative and
                    -Cannot use any space
                    